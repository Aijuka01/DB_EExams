-- Active: 1775899794870@@localhost@3306@coffeefarm

DROP DATABASE IF EXISTS coffeefarm;
CREATE DATABASE IF NOT EXISTS coffeefarm;
USE coffeefarm;


-- 1. MILESTONE THREE: STRUCTURE & VALIDATION
CREATE TABLE DISTRICT (
    district_id INT PRIMARY KEY AUTO_INCREMENT,
    district_name VARCHAR(100) NOT NULL UNIQUE,
    region VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE FARMER (
    farmer_id INT PRIMARY KEY AUTO_INCREMENT,
    national_id VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    gender ENUM('Male', 'Female') NOT NULL,
    district_id INT NOT NULL,
    registration_date DATE NOT NULL DEFAULT (CURRENT_DATE),
    FOREIGN KEY (district_id) REFERENCES DISTRICT(district_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE FARM (
    farm_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT NOT NULL,
    location_name VARCHAR(200) NOT NULL,
    size_hectares DECIMAL(8,2) NOT NULL,
    soil_type ENUM('Loam', 'Clay', 'Sandy', 'Silt', 'Peat', 'Volcanic') NOT NULL,
    coffee_species ENUM('Arabica', 'Robusta', 'Liberica') NOT NULL,
    coffee_variety VARCHAR(50) DEFAULT 'Traditional',
    year_established YEAR NOT NULL,
    CONSTRAINT chk_farm_size CHECK (size_hectares > 0),
    FOREIGN KEY (farmer_id) REFERENCES FARMER(farmer_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE COFFEE_PRODUCTION (
    production_id INT PRIMARY KEY AUTO_INCREMENT,
    farm_id INT NOT NULL,
    season_year YEAR NOT NULL,
    season_period ENUM('Main', 'Fly') NOT NULL DEFAULT 'Main',
    quantity_kg DECIMAL(10,2) NOT NULL,
    quality_grade ENUM('Grade A', 'Grade B', 'Grade C', 'Ungraded') NOT NULL,
    harvest_date DATE NOT NULL,
    CONSTRAINT chk_production_qty CHECK (quantity_kg >= 0),
    FOREIGN KEY (farm_id) REFERENCES FARM(farm_id) ON DELETE CASCADE,
    UNIQUE KEY unique_season_prod (farm_id, season_year, season_period)
) ENGINE=InnoDB;

CREATE TABLE EXTENSION_WORKER (
    worker_id INT PRIMARY KEY AUTO_INCREMENT,
    national_id VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    email VARCHAR(150) UNIQUE,
    specialization VARCHAR(150) NOT NULL,
    district_id INT NOT NULL,
    hire_date DATE NOT NULL,
    password_hash VARCHAR(255),
    FOREIGN KEY (district_id) REFERENCES DISTRICT(district_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE PRODUCT (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(200) NOT NULL UNIQUE,
    product_type ENUM('Seedling', 'Fertilizer', 'Pesticide', 'Tool') NOT NULL,
    unit VARCHAR(50) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    CONSTRAINT chk_stock_positive CHECK (stock_quantity >= 0)
) ENGINE=InnoDB;

CREATE TABLE SEEDLING_DISTRIBUTION (
    distribution_id INT PRIMARY KEY AUTO_INCREMENT,
    farm_id INT NOT NULL,
    product_id INT NOT NULL,
    worker_id INT NOT NULL,
    distribution_date DATE NOT NULL,
    quantity INT NOT NULL,
    CONSTRAINT chk_dist_qty CHECK (quantity > 0),
    FOREIGN KEY (farm_id) REFERENCES FARM(farm_id) ON DELETE RESTRICT,
    FOREIGN KEY (product_id) REFERENCES PRODUCT(product_id) ON DELETE RESTRICT,
    FOREIGN KEY (worker_id) REFERENCES EXTENSION_WORKER(worker_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE FARMER_SUPPORT (
    support_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT NOT NULL,
    worker_id INT NOT NULL,
    visit_date DATE NOT NULL,
    advice_category ENUM('Pest Control', 'Pruning', 'Soil Fertility', 'Harvesting', 'Other') NOT NULL,
    advice_details TEXT NOT NULL,
    followup_required BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (farmer_id) REFERENCES FARMER(farmer_id) ON DELETE CASCADE,
    FOREIGN KEY (worker_id) REFERENCES EXTENSION_WORKER(worker_id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- 2. SAMPLE DATA (Established vs. New Farmer)
INSERT INTO DISTRICT (district_name, region) VALUES ('Mukono', 'Central'), ('Mbale', 'Eastern');

-- FARMER 1: Established Farmer (John Mubiru)
INSERT INTO FARMER (national_id, first_name, last_name, phone, gender, district_id) 
VALUES ('CM85008654123A', 'John', 'Mubiru', '+256701000111', 'Male', 1);


-- FARM 1: Established Plantation (Started in 2018)
INSERT INTO FARM (farmer_id, location_name, size_hectares, soil_type, coffee_species, coffee_variety, year_established) 
VALUES (1, 'Kyampisi Village', 2.5, 'Loam', 'Robusta', 'Nganda', 2018);

-- FARMER 2: NEW Farmer (Sarah Namono)
INSERT INTO FARMER (national_id, first_name, last_name, phone, gender, district_id, registration_date) 
VALUES ('CF92004512346B', 'Sarah', 'Namono', '+256782222333', 'Female', 2, CURRENT_DATE);
 

-- FARM 2: NEW Plantation (Started in 2024 - Young trees)
INSERT INTO FARM (farmer_id, location_name, size_hectares, soil_type, coffee_species, coffee_variety, year_established) 
VALUES (2, 'Mount Elgon Slopes', 1.5, 'Volcanic', 'Arabica', 'SL14', 2024);

--new farmer 
INSERT INTO FARMER (national_id, first_name, last_name, phone, gender, district_id, registration_date)
VALUES ('CF100102HJL00JK', 'Josephine', 'Nakiwala', '+256785718419', 'Female', 2, CURRENT_DATE);    
SELECT farmer_id, first_name FROM FARMER WHERE  first_name = 'Josephine';
INSERT INTO FARM (farmer_id, location_name, size_hectares, soil_type, coffee_species, coffee_variety, year_established)
VALUES (3, 'Mount Elgon Slopes', 1.0, 'Volcanic', 'Arabica', 'SL14', 2024);

-- PRODUCTS & WORKERS
INSERT INTO PRODUCT (product_name, product_type, unit, stock_quantity) 
VALUES ('Arabica SL14 Seedlings', 'Seedling', 'Seedlings', 5000);

INSERT INTO EXTENSION_WORKER (national_id, first_name, last_name, phone, email, specialization, district_id, hire_date) 
VALUES ('W100', 'Alice', 'Nakalema', '+256750999888', 'alice.n@agri.go.ug', 'Crop Pathology', 1, '2022-01-15');

-- PRODUCTION (Only for Established Farmer John)
INSERT INTO COFFEE_PRODUCTION (farm_id, season_year, season_period, quantity_kg, quality_grade, harvest_date) 
VALUES (1, 2024, 'Main', 450.50, 'Grade A', '2024-05-10'), (1, 2024, 'Fly', 120.00, 'Grade B', '2024-11-20');

-- SUPPORT & DISTRIBUTION (Showing help for the NEW farmer Sarah)
INSERT INTO SEEDLING_DISTRIBUTION (farm_id, product_id, worker_id, distribution_date, quantity) 
VALUES (1, 1, 1, CURDATE(), 300), (2, 1, 1, CURDATE(), 150);

INSERT INTO FARMER_SUPPORT (farmer_id, worker_id, visit_date, advice_category, advice_details)
VALUES 
(1, 1, '2024-06-01', 'Pruning', 'Advised on older tree stumping.'),
(2, 1, CURRENT_DATE, 'Pest Control', 'Initial training for young Arabica trees.');

SELECT * FROM FARMER_SUPPORT;
SELECT * FROM SEEDLING_DISTRIBUTION;
SELECT * FROM COFFEE_PRODUCTION;
SELECT * FROM FARM;
SELECT * FROM FARMER;
SELECT * FROM EXTENSION_WORKER;
SELECT * FROM PRODUCT;
SELECT * FROM DISTRICT;




SELECT 
    f.first_name AS Farmer, 
    w.first_name AS Worker, 
    s.visit_date, 
    s.advice_category
FROM FARMER_SUPPORT s
JOIN FARMER f ON s.farmer_id = f.farmer_id
JOIN EXTENSION_WORKER w ON s.worker_id = w.worker_id;




-- 3. MILESTONE FOUR: SECURITY & AUTOMATION
CREATE ROLE IF NOT EXISTS 'admin_role', 'worker_role';
GRANT ALL PRIVILEGES ON coffeefarm.* TO 'admin_role';
GRANT SELECT, INSERT, UPDATE ON coffeefarm.FARMER TO 'worker_role';
GRANT SELECT, INSERT, UPDATE ON coffeefarm.FARM TO 'worker_role';
GRANT SELECT, INSERT, UPDATE ON coffeefarm.COFFEE_PRODUCTION TO 'worker_role';
GRANT SELECT, INSERT, UPDATE ON coffeefarm.SEEDLING_DISTRIBUTION TO 'worker_role';
GRANT SELECT, INSERT, UPDATE ON coffeefarm.FARMER_SUPPORT TO 'worker_role';

CREATE USER IF NOT EXISTS 'ministry_admin'@'localhost' IDENTIFIED BY 'AdminSecure2025!';
CREATE USER IF NOT EXISTS 'field_officer'@'localhost' IDENTIFIED BY 'FieldWork2025!';
GRANT 'admin_role' TO 'ministry_admin'@'localhost';
GRANT 'worker_role' TO 'field_officer'@'localhost';

CREATE OR REPLACE VIEW FarmerPrivacyView AS
SELECT f.first_name, f.last_name, d.district_name, CONCAT('XXXX-XXXX-', RIGHT(f.national_id, 4)) AS masked_id, f.phone
FROM FARMER f JOIN DISTRICT d ON f.district_id = d.district_id;
SELECT * FROM FarmerPrivacyView;
DELIMITER //

CREATE TRIGGER trg_auto_reduce_stock
AFTER INSERT ON SEEDLING_DISTRIBUTION
FOR EACH ROW
BEGIN
    UPDATE PRODUCT SET stock_quantity = stock_quantity - NEW.quantity WHERE product_id = NEW.product_id;
END //

CREATE TRIGGER trg_check_harvest_date
BEFORE INSERT ON COFFEE_PRODUCTION
FOR EACH ROW
BEGIN
    IF NEW.harvest_date > CURRENT_DATE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Harvest date cannot be in the future.';
    END IF;
END //

CREATE PROCEDURE RegisterWorkerSecure(IN p_national_id VARCHAR(20), IN p_raw_password VARCHAR(255))
BEGIN
    UPDATE EXTENSION_WORKER SET password_hash = SHA2(p_raw_password, 256) WHERE national_id = p_national_id;
END //

CREATE PROCEDURE GetRegionalYield(IN r_name VARCHAR(100))
BEGIN
    SELECT d.district_name, farm.coffee_species, SUM(p.quantity_kg) as Total_Yield
    FROM DISTRICT d
    JOIN FARMER f ON d.district_id = f.district_id
    JOIN FARM farm ON f.farmer_id = farm.farmer_id
    JOIN COFFEE_PRODUCTION p ON farm.farm_id = p.farm_id
    WHERE d.region = r_name
    GROUP BY d.district_name, farm.coffee_species;

    CALL GetRegionalYield('Central');

END //



DELIMITER ;

-- 4. FINAL MINISTRY STATUS REPORT

SELECT 
    f.first_name, 
    f.last_name, 
    farm.year_established,
    COALESCE(SUM(p.quantity_kg), 0) AS yield_to_date,
    CASE 
        WHEN farm.year_established >= 2024 THEN 'New Grower (High Support Need)'
        ELSE 'Established Grower (Production Phase)'
    END AS ministry_classification
FROM FARMER f
JOIN FARM farm ON f.farmer_id = farm.farmer_id
LEFT JOIN COFFEE_PRODUCTION p ON farm.farm_id = p.farm_id
-- We added the names and year to the GROUP BY to satisfy the error
GROUP BY f.farmer_id, f.first_name, f.last_name, farm.year_established;


--  SYSTEM TESTING & VERIFICATION

-- 1. PROVE AUTOMATION (Seedling Stock Reduction)
SELECT 'BEFORE' AS Status, stock_quantity FROM PRODUCT WHERE product_id = 1;
INSERT INTO SEEDLING_DISTRIBUTION (farm_id, product_id, worker_id, distribution_date, quantity) 
VALUES (1, 1, 1, CURDATE(), 500);
SELECT 'AFTER' AS Status, stock_quantity FROM PRODUCT WHERE product_id = 1;

-- 2. PROVE SECURITY (Password Hashing)
CALL RegisterWorkerSecure('W100', 'AliceSecret123');
SELECT national_id, first_name, password_hash FROM EXTENSION_WORKER WHERE national_id = 'W100';

-- 3. PROVE DATA VALIDATION (Future Date Error)
INSERT INTO COFFEE_PRODUCTION (farm_id, season_year, season_period, quantity_kg, quality_grade, harvest_date) 
VALUES (1, 2027, 'Main', 500, 'Grade A', '2027-12-31');



